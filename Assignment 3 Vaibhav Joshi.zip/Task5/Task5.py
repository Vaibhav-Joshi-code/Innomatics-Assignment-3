import math
from math import *
a = int(input())
b = int(input())
m = int(input())
if (a,b>=1 and a,b<=10) and (m>=2 and m<=1000):
    print(int(pow(a,b)))
    print(int(pow(a,b)%m))
