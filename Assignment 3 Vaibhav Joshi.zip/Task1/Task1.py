import cmath
from cmath import *
r = eval(input())
i = eval(input())
z = complex(real=r,imag=i)
m = polar(z)
print(round(m[0],3))
print(round(m[1],3))
