import math
from math import *
x = [i for i in range(101)]
AB = int(input())
BC = int(input())
if (AB in x) and (BC in x):
    ang = atan(AB/BC)
    deg = (ang*180)/pi
    degk = floor(deg)
print(str(degk)+'°')
