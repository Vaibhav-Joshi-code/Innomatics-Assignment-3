a = int(input())
b = int(input())
c = int(input())
d = int(input())
if (a,b,c,d>=1 and a,b,c,d<=1000):
    print((pow(a,b))+(pow(c,d)))
